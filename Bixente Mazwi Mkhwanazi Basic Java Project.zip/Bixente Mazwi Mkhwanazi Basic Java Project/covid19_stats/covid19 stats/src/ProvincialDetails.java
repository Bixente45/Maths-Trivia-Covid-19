/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


class ProvincialDetails {

    void setProvinceName(String string) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    void setTotalCases(int aInt) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    void setPercentageTotal(double aDouble) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    String getProvinceName() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    String getTotalCases() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    String getPercentageTotal() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
