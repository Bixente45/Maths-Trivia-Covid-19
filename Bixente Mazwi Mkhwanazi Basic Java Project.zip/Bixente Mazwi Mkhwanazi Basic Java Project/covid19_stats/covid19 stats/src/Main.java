import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<ProvincialDetails> provinceList = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/covid19_stats", "root", "")) {
            String query = "SELECT * FROM province_statistics";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                ProvincialDetails province = new ProvincialDetails();
                province.setProvinceName(resultSet.getString("province_name"));
                province.setTotalCases(resultSet.getInt("total_cases"));
                province.setPercentageTotal(resultSet.getDouble("percentage_total"));
                provinceList.add(province);
            }
        } catch (SQLException e) {
        }

        for (ProvincialDetails province : provinceList) {
            System.out.println("Province: " + province.getProvinceName());
            System.out.println("Total Cases: " + province.getTotalCases());
            System.out.println("Percentage Total: " + province.getPercentageTotal() + "%\n");
        }
    }
}
