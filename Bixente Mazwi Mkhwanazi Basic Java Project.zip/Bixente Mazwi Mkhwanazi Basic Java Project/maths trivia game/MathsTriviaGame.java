import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;

public class MathsTriviaGame {
public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    Random random = new Random();
    HashSet<String> correctAnswers = new HashSet<>();

    System.out.println("Welcome to the Maths Trivia Game");

    while (true) { 
        int num1 = random.nextInt(10) + 1;
        int num2 = random.nextInt(10) + 1;
        char [] operators = {'+', '-', '*', '/'};
        char operator = operators[random.nextInt(3)];

        System.out.println("What is: " + num1 + " " + operator + " " + num2 + "?");
        int userAnswer = scanner.nextInt();

       int correctAnswer = 0;
       switch (operator) {
           case '+' -> correctAnswer = num1 + num2;
           case '*' -> correctAnswer = num1 * num2;
           case '/' -> correctAnswer = num1 / num2;
       }

       if (userAnswer == 999) {
               break;
        }
        
        if (userAnswer == correctAnswer) {
        
            System.out.println("Well done, thats correct!");  
        } else {
            System.out.println("Wrong answer, the correct answer is:" + correctAnswer);
        }
           
    }
    
    System.out.println("Correct answers in Hashset");
    for (String answer : correctAnswers) {
        System.out.println(answer);      
    }
    
}
}